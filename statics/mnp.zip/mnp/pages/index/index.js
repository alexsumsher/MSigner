//index.js
//获取应用实例
const app = getApp();
const signer = require('../../utils/school.js');
Page({
  data: {
    is_reg: false,
    userid: '',
    username: '',
    password: '',
    sign_status: "unsigned",
    sign_text: '未签到',
    sch_array: [],
    sch_id: null, // objid
    sch_name: '',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    next_meeting: {
      mid: 0,
      nextdtime: '',
      name: '当日无会议',
      roomname: '',
    }
  },
  // vars
  regcode: null,
  _env: {

    working: false,
    places: ['大会议室', '小会议室', '礼堂', '活动室', '408'],
    meettings: [],
    _objid: null,
    openid: null,
    empty_meeting: { mid: 0, name: "NO", },
  },
  _meeting_generator: function(date, time, place){
    let aday = 24 * 60 * 60 * 1000;
    if (!date){
      let nowtime = new Date().getTime();
      let offset_days = Math.round(Math.random() * 7);
      let offset_date = nowtime + offset_days * aday;
      date = new Date(offset_date);
    } else if (date <= 7){
      // offset of day
      let offset_date = nowtime + date * aday;
      date = new Date(offset_date);
    } else if (typeof(date) === 'string') {
      newdate = new Date(date);
    }
    // limit offset of 7day
    if (!time){
      let _rnd = Math.random();
      time = 8 + Math.round(_rnd) * 10 + (_rnd>0.5?':30':':00');
    }
    if (!place){
      let ln = this._env.places.length - 1;
      place = this._env.places[Math.round(Math.random() * ln)];
    }
    return {
      name: '会议名',
      mid: Math.round(Math.random() * 100),
      nextdtime: date.toLocaleDateString(),
      roomname: place
    }
  },

  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  act_keyin: function(e){
    console.log(e.target.dataset.key + e.detail.value);
    let k = e.target.dataset.key,
        v = e.detail.value;
    this.setData({ [k]: v});
  },
  // 选择学校
  sch_choose: function(e){
    console.log(e);
    let v = parseInt(e.detail.value);
    let n = this.data.sch_array[v].title;
    this._env._objid = this.data.sch_array[v].ikey;
    console.log(this._env);
    this.setData({sch_name: n });
  },
  // beacon
  goBeacon: function(){
    wx.navigateTo({
      url: '../beacontest/ibeacon',
    })
  },
  goSign: function(){
    setTimeout(()=>{
      wx.showToast({
        title: '签到成功！',
      });
      this.setData({ sign_status: 'signed', sign_text: '已签到'});
    }, 450);
  },
  goSign2: function(){
    if (this._env.working){
      // turn off
      signer.do_beacon(-1);
      this._env.working = false;
      return;
    }
    this._env.working = true;
    const onok = (data)=>{
      wx.showToast({
        title: data.ble[0].mac,
      });
      this.setData({ sign_status: 'signed', sign_text: '已签到' });
      signer.do_beacon(-1);
    };
    signer.do_beacon(5, null, onok);
  },
  testSign: function(){
    wx.showToast({
      title: '签到!',
    })
  },

  goSign3: function(){
    const onok = (found) => {
      if (found){
        this.setData({ sign_status: 'signed', sign_text: '已签到' });
      }
      wx.showToast({
        title: found?"签到成功":"签到失败(不在有效距离内)",
      });
    };
    signer.do_beacon2(5, null, onok);
  },

  mymeetings: function(){
    wx.navigateTo({
      url: '../mlists/mlists',
    })
  },

  load_schools: function(){
    wx.request({
      url: 'https://htattend.yunisky.cn/wxuser?action=schoolist',
      success: res => {
        let rsp = res.data;
        if (rsp && rsp.success == "yes"){
          this.setData({sch_array: rsp.data});
        }
      },
      fail: res => {
        wx.showToast({
          title: '失败！获取学校列表。',
          icon: 'warn'
        })
      },
    });
  },

  login: function(){
    // 发送 res.code 到后台换取 openId, sessionKey, unionId
    let page = this;
    wx.request({
      url: 'https://htattend.yunisky.cn/wxuser?js_code=' + app.globalData.login_code,
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: res => {
        var rsp = res.data;
        if (rsp.success = 'yes') {
          if (rsp.userid) {
            wx.showToast({
              title: '用户已识别，登录成功',
            });
            page._env.userid=rsp.userid;
            page.setData({ is_reg: true, userid: rsp.userid });
            // afeter
            this.load_meetings(rsp.userid);
          } else {
            wx.showToast({
              title: '未注册用户，稍后请注册',
              icon: 'warn',
            });
            page.load_schools();
            page.setData({ is_reg: false });
          }
          page._env.openid = rsp.openid;
          app.globalData.userid = rsp.userid;
          app.globalData.openid = rsp.openid;
        } else {
          wx.showToast({
            title: '无法连接到服务器！',
            icon: 'warn',
          })
        }
        wx.hideLoading();
      },
      fail: (e) => { wx.hideLoading();}
    })
  },
  nettset: function(){
    wx.request({
      url: 'https://www.sirukeji.com/zhongk/inf/weix/login',
      success: (res)=>{
        wx.showToast({
          title: 'return success res with:' + res.length,
        })
      },
      error: (res)=>{
        wx.showToast({
          title: 'return error res with:' + res.length,
        })
      },
    });
  },
  doreg: function(){
    // 测试注册
    console.log("go for regist")
    //this.openid = wx.getStorageSync('openid');
    this.openid = this._env.openid;
    wx.request({
      url: 'https://htattend.yunisky.cn/wxuser?action=regist',
      data: {
        openid: this._env.openid,
        schoolid: this._env._objid,
        userid: this.data.userid,
        username: this.data.username,
        password: this.data.password
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'POST',
      success: res => {
        let rsp = res.data;
        if (rsp.success == 'yes') {
          wx.showToast({
            title: '注册成功！',
          });
          this.setData({ is_reg: true});
        } else {
          wx.showToast({
            title: '注册失败，请联系。。。。',
            icon: 'warn'
          })
        }
      },
    })
  },

  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
    
    /* set meetings
    this._env.meettings = [];
    let m1 = this._meeting_generator();
    console.log(m1);
    this.setData({ next_meeting: m1});
    */
  },

  onReady: function(){
    wx.showLoading({
      title: '登录系统',
    })
    setTimeout(this.login, 500);
    //this.login();
  },

  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  load_meetings: function(userid){
    userid = userid || app.globalData.userid;
    wx.request({
      url: 'https://htattend.yunisky.cn/resource/meeting?action=mylist&userid=' + userid,
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: res => {
        if (res.data.success === 'yes'){
          let meetings = res.data.data;
          console.log(meetings);
          if (!meetings){
            wx.showToast({
              title: '无会议',
              icon: 'cancel'
            })
          }
          if (meetings && meetings.length > 0){
            // range for next meeting
            app.globalData.meetings = meetings;
            let m1,dt,now=new Date();
            let smin = 24 * 60 * 60 * 1000;
            meetings.forEach((n)=>{
              console.log(n.nextdtime);
              dt = new Date(n.nextdtime) - now;
              console.log("dt: " + dt);
              if (dt > 0 && dt < smin){
                m1 = n;
                smin = dt;
              }
            });
            if (m1){
              this.setData({ next_meeting: m1, status: m1.status == 1 ? "signed" :"unsigned" });
            } else{
              console.log("no next meeting");
            }
          }
        }
      },
    })
  },
})
